import React from "react";

const Footer = () => {
  return (
    <div className="bg-primary text-white text-center py-4">
      <div>copyright &copy; 2024 || TCJ-Space</div>
    </div>
  );
};

export default Footer;
