package com.example.school_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
