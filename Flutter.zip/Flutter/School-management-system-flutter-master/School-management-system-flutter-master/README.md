# School Management App UI Flutter | Backend Firebase

Flutter based School Management App | Flutter | Backend Firebase

## Demo
Demo available on YouTube.

Link: https://www.youtube.com/watch?v=roZYSxsk-ho

## Screenshot

![school mngt ui](https://user-images.githubusercontent.com/54774962/102515635-ff363b80-40b3-11eb-82e7-8b3872815ce1.png)


